function validarYEnviar(event) {
    var email = document.getElementById("email").value;
    var terms = document.getElementById("terms").checked;
    var errores = [];

    if (email.trim() === "") {
        errores.push("El campo de correo electrónico es obligatorio.");
    }

    if (!terms) {
        errores.push("Debes aceptar nuestros términos legales.");
    }

    if (errores.length > 0) {
        var mensajeError = errores.join("\n");
        alert(mensajeError);
        event.preventDefault(); 
    } else {
        window.location.href = "/";
        event.preventDefault();
    }
}
